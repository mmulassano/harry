from django.shortcuts import render
from models import ThreatDetail,Threat,TypeThreat,Detection,Seen,Note,Picture
from mapeo.models import Activity, Parcel,TypeCrop
from pushes.models import Device
from pushes.views import push_notifications_view

from rest_framework import viewsets
from serializers import TypeThreatSerializer, ThreatSerializer, DetectionSerializer,NoteSerializer,PictureSerializer,SeenSerializer

from rest_framework.decorators import api_view
from rest_framework import viewsets, request
from rest_framework.response import Response
from rest_framework.renderers import JSONRenderer
from rest_framework import status
from django.http import HttpResponse
from django.db import transaction, IntegrityError
from pyfcm import FCMNotification

from django.views.decorators.csrf import csrf_exempt
from rest_framework.parsers import JSONParser

from django.core.exceptions import ObjectDoesNotExist
import datetime

#...........
from django.contrib.auth import get_user_model
UserModel = get_user_model()

class JSONResponse(HttpResponse):
    """
    An HttpResponse that renders its content into JSON.
    """
    def __init__(self, data, **kwargs):
        content = JSONRenderer().render(data)
        kwargs['content_type'] = 'application/json'
        super(JSONResponse, self).__init__(content, **kwargs)

class TypeThreatViewSet(viewsets.ModelViewSet):
    """
    API endpoint that allows users to be viewed or edited.
    """
    queryset = TypeThreat.objects.all().order_by()
    serializer_class = TypeThreatSerializer



class ThreatViewSet(viewsets.ModelViewSet):
    queryset = Threat.objects.all().order_by()
    serializer_class = ThreatSerializer


##########AMENAZAS
##################################
#consulta de las amenazas,
@api_view(['GET'])
def threat(request):
    if request.method == 'GET':
       #threats = Threat.objects.filter()
       #serializer = ThreatSerializer(threats, many=True)
       threatDetails = ThreatDetail.objects.filter()
       list_threat = []

       for objectThreatDetail in threatDetails:
           #serializer = ThreatSerializer(objectThreat)
            id_threat=objectThreatDetail.threat_id
            threats = Threat.objects.filter(id=id_threat)
            for objectThreat in threats:
                name = objectThreat.name
                scientific_name= objectThreat.scientific_name
                description = objectThreat.description
                wikipedia_link = objectThreat.wikipedia_link

            datatime = ""
            distance_min = 0
            valorization = 0
            sum_detection=0
            sum_seen = 0
            image_url='sin imagen'
            detection = Detection.objects.filter(threatDetail_id=objectThreatDetail.id)
            for objectDetection in detection:
                sum_detection = sum_detection +1
                datatime =  objectDetection.date
                distance_min = 2.5
                valorization = 3

                picture = Picture.objects.filter(object_id=objectDetection.movil_id)
                for objectPicture in picture:
                    image_url = 'imagen'

                seens = Seen.objects.filter(object_id=id_threat, object_type="threat")
                for objectSeen in seens:
                    sum_seen = sum_seen + 1


            dato = {
                    "threat_id":id_threat,
                    "name": name,
                    "scientific_name": scientific_name,
                    "description": description,
                    "wikipedia_link": wikipedia_link,
                    "typeThreat_id":objectThreat.typeThreat_id,
                    "crop_id": objectThreatDetail.typeCrop_id,
                    "detection_sum": sum_detection,
                    "seen_sum": sum_seen,
                    "image": image_url,
                    "datetime_last": datatime,
                    "distance_min": distance_min,
                    "valorization": valorization         #0 - 4
                }
            list_threat.append(dato)
       return JSONResponse(list_threat)


##### DETECCION
##################################
# Agrega y modifica actividades de lote

@api_view(['POST', 'GET'])
def detection(request):
    if request.method == 'POST':
       try:
           with transaction.atomic():
               datos_detection = {}
               datos_note = {}

               movil_id = request.POST['movil_id']

               datos_detection['user_id'] = request.user.id
               datos_detection['movil_id'] = movil_id
               datos_detection['date'] = request.POST['date']
               datos_detection['damage_level'] = request.POST['damage_level']
               datos_detection['threatDetail_id'] = request.POST['threat_id']

               datos_note['user_id'] = request.user.id
               datos_note['object_id'] = movil_id
               datos_note['object_type'] = "Detection"
               datos_note['content'] = request.POST['note']

               import json
               actividades = request.POST['activity_id']
               actividades2 = actividades.replace("\\" ,"")
               actividades_json = json.loads(actividades2)


               for registroActividad in actividades_json:
                   activity_id = registroActividad['id']
                   datos_detection['activity_id'] = activity_id
                   existen = Detection.objects.filter(movil_id=movil_id,activity_id=activity_id).count()
                   if (existen == 0):
                        serializer = DetectionSerializer(data=datos_detection)
                        if serializer.is_valid():
                            serializer.save()
                        else:
                            raise AttributeError
                   else:
                        #ACTUALIZO
                        detection = Detection.objects.filter(movil_id=movil_id,activity_id=activity_id)
                        for objectDetection in detection:
                            serializer = DetectionSerializer(objectDetection, data=datos_detection)
                            if serializer.is_valid():
                                serializer.save()
                            else:
                                raise AttributeError

               nota(datos_note)
               #if(request.FILES['image']):
               image(request)
                   #print request.FILES['image']


               #PUSH envio notificacion
               push(datos_detection['threatDetail_id'], activity_id)



           return Response({"success": ("GUARDA TODO")}, status=status.HTTP_200_OK)
       except (AttributeError, ObjectDoesNotExist):
              pass
              return Response({"error": ("NO GUARDA NADA")}, status=status.HTTP_400_BAD_REQUEST)

    if request.method == 'GET':
        detections = Detection.objects.filter()
        serializer = DetectionSerializer(detections, many=True)
        return JSONResponse(serializer.data)

def push(amenaza_id,activity_id):
    #actividad = Activity.objects.get(movil_id=activity_id)
    #crop = TypeCrop.objects.get(id=actividad.type_crop_id)
    #cultivo = crop.name

    #cantidad = Detection.objects.filter(activity_id=activity_id,threatDetail_id=amenaza_id).count()
    cantidad = 6
    #print cultivo
    amenaza = Threat.objects.get(id=amenaza_id)
    nombre_amenaza = amenaza.name
    #print nombre_amenaza
    dispositivos = Device.objects.filter(active=True)
    for objectDevice in dispositivos:
       key_firebase = objectDevice.key_firebase
       #print key_firebase
       title = "¡Se aproximan " + nombre_amenaza + "!"
       body = cantidad + " nuevas detecciones en tu zona"
       resultado = push_notifications_view(key_firebase, title, body)
       print resultado



def nota(datos_note):
    object_id = datos_note['object_id']
    existeNota = Note.objects.filter(object_id=object_id).count()
    if (existeNota == 0):
        serializerNote = NoteSerializer(data=datos_note)
        if serializerNote.is_valid():
            serializerNote.save()
        else:
            raise AttributeError
    else:
        # ACTUALIZO
        detection = Detection.objects.filter(movil_id=object_id)
        for objectNote in detection:
            serializer = DetectionSerializer(objectNote, data=datos_note)
            if serializer.is_valid():
                serializer.save()
            else:
                raise AttributeError


def image(request):
    request.POST['object_id'] = request.POST['movil_id']
    request.POST['object_type'] = "Detection"
    object_id = request.POST['movil_id']
    imagen = request.FILES['image']
    print "aca"+imagen

    existeImage = Picture.objects.filter(object_id=object_id).count()
    if (existeImage == 0):
            serializer = PictureSerializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
            else:
                raise AttributeError
    else:
            # ACTUALIZO
            picture = Picture.objects.filter(object_id=object_id)
            for objectImage in picture:
                serializer = PictureSerializer(objectImage, data=request.data)
                if serializer.is_valid():
                    serializer.save()
                else:
                    raise AttributeError



#detection-user
@api_view(['GET'])
def detectionUser(request):
    if request.method == 'GET':

        list_detection = []
        image_url = "sin imagen"
        note="sin comentario"
        va = 3
        list_activity = []

        detections = Detection.objects.filter(user_id=request.user.id)
        for objectDetection in detections:

            notes = Note.objects.filter(user_id=request.user.id, object_id=objectDetection.movil_id,object_type="Detection")
            for objectNote in notes:
                note = objectNote.content

            picture = Picture.objects.filter(object_id=objectDetection.movil_id)
            for objectPicture in picture:
                image_url = 'imagen'

            activity_id = objectDetection.activity_id
            activites = Activity.objects.filter(user_id=request.user.id,movil_id=activity_id)
            for objectActivity in activites:
                activity_movil_id = objectActivity.movil_id
                dato_activity = {"activity_movil_id": activity_movil_id }
                list_activity.append(dato_activity)


            dato = {
                "movil_id": objectDetection.movil_id,
                "date": objectDetection.date,
                "threat_id": objectDetection.threatDetail_id,
                "note": note,
                "user_id": objectDetection.user_id,
                "image": image_url,
                "index_va":va,
                "activites": list_activity
            }
            list_activity = []
            list_detection.append(dato)

        return JSONResponse(list_detection)



@api_view(['GET'])
def detectionThreat(request,threat_id):
    if request.method == 'GET':

        list_detection = []
        image_url = "sin imagen"
        note = "sin comentario"
        sum_seen= 0
        sum_note = 0
        user = request.user.username
        center_lat = 0
        center_long = 0

        detections = Detection.objects.filter(threatDetail_id=threat_id)
        for objectDetection in detections:
            activites = Activity.objects.filter(movil_id=objectDetection.activity_id)
            for objectActivity in activites:
                parcels = Parcel.objects.filter(movil_id=objectActivity.parcel_id)
                for objectParcel in parcels:
                    center_lat = objectParcel.center_lat
                    center_long = objectParcel.center_long

            seens = Seen.objects.filter(object_id=threat_id,object_type="threat")
            for objectSeen in seens:
                sum_seen = sum_seen + 1

            dato = {
                    "movil_id": objectDetection.movil_id,
                    "date": objectDetection.date,
                    "damage_level": objectDetection.damage_level,
                    "threat_id": objectDetection.threatDetail_id,
                    "note": note,
                    "user": user,
                    "image": image_url,
                    "center_lat": center_lat,
                    "center_long": center_long,
                    "seen_sum": sum_seen,
                    "note_sum": sum_note
            }
            list_detection.append(dato)

        return JSONResponse(list_detection)


class PictureViewSet(viewsets.ModelViewSet):
    queryset = Picture.objects.all().order_by()
    serializer_class = PictureSerializer

# return Response({"error": ("NO GUARDA NADA")}, status=status.HTTP_400_BAD_REQUEST)
#Vista agregar y modificar deteccion y detalle



##### VISTOS
##################################
# Agrega y modifica actividades de lote
@api_view(['POST', 'GET'])
def seen(request):
    if request.method == 'POST':
        try:
            with transaction.atomic():
                for registro in request.data:
                    registro['user_id'] = request.user.id
                    #('user_id', 'object_id', 'object_type', 'date_time')
                    existeImage = Seen.objects.filter(object_id=registro['object_id'],object_type=registro['object_type'],user_id=registro['user_id']).count()
                    if (existeImage == 0):
                        serializer = SeenSerializer(data=registro)
                        if serializer.is_valid():
                            serializer.save()
                        else:
                            raise AttributeError
                    else:
                        # ACTUALIZO
                        detection = Detection.objects.filter(object_id=registro['object_id'],object_type=registro['object_type'],user_id=registro['user_id'])
                        for objectNote in detection:
                            serializer = DetectionSerializer(objectNote, data=registro)
                            if serializer.is_valid():
                                serializer.save()
                            else:
                                raise AttributeError

            return Response({"success": ("GUARDA TODO")}, status=status.HTTP_200_OK)
        except (AttributeError, ObjectDoesNotExist):
            pass
            return Response({"error": ("NO GUARDA NADA")}, status=status.HTTP_400_BAD_REQUEST)

    if request.method == 'GET':
        seens = Seen.objects.filter()
        serializer = SeenSerializer(seens, many=True)
        return JSONResponse(serializer.data)